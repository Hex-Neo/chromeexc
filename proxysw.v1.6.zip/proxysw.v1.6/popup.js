document.addEventListener('DOMContentLoaded', function() {
  chrome.storage.sync.get(['proxyAddress', 'proxyPort', 'proxyType', 'connectionMode', 'savedProxies'], function(data) {
    if (data.proxyAddress) document.getElementById('proxyAddress').value = data.proxyAddress;
    if (data.proxyPort) document.getElementById('proxyPort').value = data.proxyPort;
    document.getElementById('proxyType').value = data.proxyType || 'http';
    const mode = data.connectionMode || 'disabled';
    updateButtonState(mode);
    updateSavedProxies(data.savedProxies || []);
  });

  document.getElementById('toggleButton').addEventListener('click', function() {
    const proxyAddress = document.getElementById('proxyAddress').value.trim();
    const proxyPort = document.getElementById('proxyPort').value.trim();
    const proxyType = document.getElementById('proxyType').value; 
    const currentMode = document.getElementById('toggleButton').textContent === '启用代理' ? 'disabled' : 'enabled';

    if (currentMode === 'disabled') {
      if (!proxyAddress || !proxyPort) {
        alert('请填写代理地址和端口');
        return;
      }

      chrome.storage.sync.set({
        proxyAddress: proxyAddress,
        proxyPort: proxyPort,
        proxyType: proxyType, 
        connectionMode: 'enabled'
      });

      const proxyConfig = {
        mode: 'fixed_servers',
        rules: {
          singleProxy: {
            scheme: proxyType, 
            host: proxyAddress,
            port: parseInt(proxyPort)
          },
          bypassList: ['localhost']
        }
      };

      chrome.proxy.settings.set({ value: proxyConfig, scope: 'regular' }, function() {
        updateButtonState('enabled');
      });
    } else {
      chrome.storage.sync.set({ connectionMode: 'disabled' });
      chrome.proxy.settings.clear({ scope: 'regular' }, function() {
        updateButtonState('disabled');
      });
    }
  });

  document.getElementById('directButton').addEventListener('click', function() {
    chrome.storage.sync.set({ connectionMode: 'direct' });
    const directConfig = { mode: 'direct' };
    chrome.proxy.settings.set({ value: directConfig, scope: 'regular' }, function() {
      updateButtonState('direct');
    });
  });
  document.getElementById('systemButton').addEventListener('click', function() {
    chrome.storage.sync.set({ connectionMode: 'system' });
    const systemConfig = { mode: 'system' };
    chrome.proxy.settings.set({ value: systemConfig, scope: 'regular' }, function() {
      updateButtonState('system');
    });
  });

  document.getElementById('saveButton').addEventListener('click', function() {
    const proxyAddress = document.getElementById('proxyAddress').value.trim();
    const proxyPort = document.getElementById('proxyPort').value.trim();
    const proxyType = document.getElementById('proxyType').value;
    const saveName = document.getElementById('saveName').value.trim();

    if (!proxyAddress || !proxyPort || !saveName) {
      alert('请填写代理地址、端口和保存名称');
      return;
    }

    chrome.storage.sync.get(['savedProxies'], function(data) {
      const savedProxies = data.savedProxies || [];
      savedProxies.push({ 
        name: saveName, 
        address: proxyAddress, 
        port: proxyPort,
        type: proxyType 
      });
      chrome.storage.sync.set({ savedProxies: savedProxies }, function() {
        alert('配置已保存');
        updateSavedProxies(savedProxies);
      });
    });
  });

  document.getElementById('deleteButton').addEventListener('click', function() {
    const selectedProxy = document.getElementById('savedProxies').value;
    if (!selectedProxy) {
      alert('请选择要删除的配置');
      return;
    }

    chrome.storage.sync.get(['savedProxies'], function(data) {
      const savedProxies = data.savedProxies || [];
      const filteredProxies = savedProxies.filter(proxy => proxy.name !== selectedProxy);
      chrome.storage.sync.set({ savedProxies: filteredProxies }, function() {
        alert('配置已删除');
        updateSavedProxies(filteredProxies);
      });
    });
  });

  document.getElementById('savedProxies').addEventListener('change', function() {
    const selectedProxy = this.value;
    if (!selectedProxy) return;

    chrome.storage.sync.get(['savedProxies'], function(data) {
      const savedProxies = data.savedProxies || [];
      const selected = savedProxies.find(proxy => proxy.name === selectedProxy);
      if (selected) {
        document.getElementById('proxyAddress').value = selected.address;
        document.getElementById('proxyPort').value = selected.port;
        document.getElementById('proxyType').value = selected.type; 
        document.getElementById('saveName').value = selected.name;
      }
    });
  });

  function updateButtonState(mode) {
    const toggleButton = document.getElementById('toggleButton');
    const status = document.getElementById('status');
    status.className = 'status';
    
    switch(mode) {
      case 'enabled':
        toggleButton.textContent = '禁用代理';
        status.textContent = '当前状态: 已启用代理';
        status.classList.add('enabled');
        break;
      case 'direct':
        toggleButton.textContent = '启用代理';
        status.textContent = '当前状态: 直接连接（无代理）';
        status.classList.add('direct');
        break;
      case 'system':
        toggleButton.textContent = '启用代理';
        status.textContent = '当前状态: 使用系统代理';
        status.classList.add('system');
        break;
      default:
        toggleButton.textContent = '启用代理';
        status.textContent = '当前状态: 未启用';
        status.classList.add('disabled');
    }
  }

  function updateSavedProxies(proxies) {
    const select = document.getElementById('savedProxies');
    select.innerHTML = '<option value="">-- 选择保存的代理 --</option>';
    
    proxies.forEach(proxy => {
      const option = document.createElement('option');
      option.value = proxy.name;
      option.textContent = `${proxy.name} (${proxy.type})`;
      select.appendChild(option);
    });
  }
});