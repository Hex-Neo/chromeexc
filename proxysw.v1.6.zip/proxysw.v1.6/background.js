chrome.proxy.settings.onChange.addListener(function(details) {
  chrome.proxy.settings.get({ incognito: false }, function(config) {
    if (config.value) {
      if (config.value.mode === 'system') {
        chrome.storage.sync.set({ connectionMode: 'system' });
        return;
      }
      
      if (config.value.mode === 'fixed_servers') {
        const proxy = config.value.rules.singleProxy;
        chrome.storage.sync.set({
          proxyAddress: proxy.host,
          proxyPort: proxy.port.toString(), 
          proxyType: proxy.scheme, 
          connectionMode: 'enabled'
        });
      } 
      else if (config.value.mode === 'direct') {
        chrome.storage.sync.set({ connectionMode: 'direct' });
      } 
      else {
        chrome.storage.sync.get(['connectionMode'], function(data) {
          if (data.connectionMode !== 'direct' && data.connectionMode !== 'system') {
            chrome.storage.sync.set({ connectionMode: 'disabled' });
          }
        });
      }
    } else {
      chrome.storage.sync.set({ connectionMode: 'disabled' });
    }
  });
});